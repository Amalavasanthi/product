import React from 'react'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import Signup from './components/Signup'
import Login from './components/Login'
import Products from './components/Products'
import Cart from './components/Cart'
import Productdetails from './components/Productdetails'

const App = () => {
  return (
   <>
   <BrowserRouter>
   <Routes>
    <Route path="/" element={<Signup/>}></Route>
    <Route path="/login" element={<Login/>}></Route>
    <Route path="/products" element={<Products/>}></Route>
    <Route path="/products/:pid" element={<Productdetails/>}></Route>
    <Route path="/cart" element={<Cart/>}></Route>
   </Routes>
   </BrowserRouter>
   </>
  )
}

export default App