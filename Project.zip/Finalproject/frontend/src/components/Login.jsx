import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';
const Login = () => {

    let [loginEmail, setloginEmail] = useState("")
    let [loginPassword, setloginPassword] = useState("")

    let navigate = useNavigate()
    let handleLogin = async (e) => {

        e.preventDefault()
        let res = await axios.get("http://localhost:3000/users")
        let users = res.data
        console.log(users);
        let user = users.find((ele) => ele.Email == loginEmail && ele.Pass == loginPassword)
        console.log(user);
        if (user) {
            alert("login done")
            navigate("/products")

        }
        else {
            alert("wrong credencials")
        }
    }
    return (
        <>
            <div className='login'>

                <div className="logininner">
                    <h2 className='h2'>LoginPage</h2>
                    <form action="" onSubmit={handleLogin}>

                        <label htmlFor="">Email</label>
                        <input type="email" placeholder='enter your email' value={loginEmail} onChange={(e) => setloginEmail(e.target.value)} />
                        <label htmalFor="">Password</label>
                        <input type="password" placeholder='enter your password' value={loginPassword} onChange={(e) => setloginPassword(e.target.value)} />
                        <button >Login</button>
                    </form>
                    <footer>
                        <p>Dont have an Accout?</p>
                        <Link to="/">Signup</Link>
                    </footer>
                </div>
            </div></>
    )
}

export default Login