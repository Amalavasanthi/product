import React from 'react'
import { NavLink } from 'react-router-dom'

const Navbar = () => {
  return (
    <>
    <nav>
     
        <h2>Products</h2>
        <ul>
           <NavLink to='/cart'>Cart</NavLink>
           <NavLink to='/products'>Products</NavLink>
        </ul>
        </nav></>
  )
}

export default Navbar